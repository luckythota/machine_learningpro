# -*- coding: utf-8 -*-
"""
Created on Mon Sep 25 12:17:50 2023

@author: NAGA LAKSHMI
"""

import pandas as pd
import numpy as np

data=pd.read_csv(r'E:/cpp programs/New folder/New folder/Tetuan City power consumption.csv')
data
data.isna().sum()


data['day']=pd.to_datetime(data['DateTime']).dt.day
data['month']=pd.to_datetime(data['DateTime']).dt.month
data['years']=pd.to_datetime(data['DateTime']).dt.year
data['hours']=pd.to_datetime(data['DateTime']).dt.hour
data['minutes']=pd.to_datetime(data['DateTime']).dt.minute

data1=data.drop('DateTime',axis=1)

data1

x=data1.iloc[: ,[0,1,2,3,4,8,9,10,11,12]].values
y=data1.iloc[: ,[5,6,7]].values

from sklearn.model_selection import train_test_split #testsize also not fixed
xtrain,xtest,ytrain,ytest=train_test_split(x,y,test_size=0.3,random_state=10) #random state is not fixed


from sklearn.linear_model import LinearRegression
model=LinearRegression()
model.fit(xtrain,ytrain)

ypred=model.predict(xtest)


from sklearn.metrics import mean_squared_error
import math
math.sqrt(mean_squared_error(ytest, ypred))



